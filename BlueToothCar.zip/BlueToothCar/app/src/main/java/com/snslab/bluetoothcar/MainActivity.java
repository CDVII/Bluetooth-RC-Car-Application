package com.snslab.bluetoothcar;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private static final String HC06_UUID = "00001101-0000-1000-8000-00805F9B34FB";
    private static final int REQUEST_ENABLE_BT = 20;         // 요청가능한 블루투스 장치 개수
    private BluetoothAdapter mBluetoothAdapter;  // 블루투스 어댑터
    private Set<BluetoothDevice> mDevices;      // 페어링된 블루투스 장치 목록
    private int mPairedDeviceCount;            // 페어링된 불루투스 장치 개수
    private BluetoothDevice mRemoteDevice;      // 연결된 장치
    private BluetoothSocket mSocket;
    private OutputStream mOutputStream;         // 송신 스트림

    private int[] buttonID = {R.id.buttonFront, R.id.buttonBack, R.id.buttonLeft, R.id.buttonRight, R.id.buttonFast, R.id.buttonSlow};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for(int ID : buttonID)
            findViewById(ID).setOnClickListener(this);

        if(!setBluetooth())
            finish();
        selectBluetoothDevice();
    }

    @Override
    protected void onDestroy() {
        try{
            mOutputStream.close();
            mSocket.close();
        }catch(Exception e){}
        super.onDestroy();
    }

    /**
     * View.OnClickListener의 구현 메소드
     * @param view
     */
    @Override
    public void onClick(View view) {
        String message = new String();
        switch(view.getId()){
            case R.id.buttonFront:
                message = "w";
                break;
            case R.id.buttonBack:
                message = "s";
                break;
            case R.id.buttonLeft:
                message = "a";
                break;
            case R.id.buttonRight:
                message = "d";
                break;
            case R.id.buttonFast:
                message = "[";
                break;
            case R.id.buttonSlow:
                message = "]";
                break;
        }
        sendData(message);
    }

    /**
     * 블루투스 설정을 담당하는 메소드
     * @return 블루투스 설정을 성공하면 true.
     */
    protected boolean setBluetooth() {
        if (setBluetoothAdapter()) {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            return true;
        }
        return false;
    }

    private boolean setBluetoothAdapter() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mBluetoothAdapter == null)   // 장치가 블루투스를 지원하지 않음
            return false;
        return true;
    }

    private void selectBluetoothDevice() {
        mDevices = mBluetoothAdapter.getBondedDevices();
        mPairedDeviceCount = mDevices.size();

        if(mPairedDeviceCount == 0) // 페어링 된 장치가 없는 경우
            finish();		// 어플리케이션 종료

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("블루투스 장치 선택");

        // 페어링 된 블루투스 장치의 이름 목록 작성
        List<String> listItems = new ArrayList<String>();
        for (BluetoothDevice device : mDevices)
            listItems.add(device.getName());
        listItems.add("취소");		// 취소 항목 추가

        final CharSequence[] items = listItems.toArray(new CharSequence[listItems.size()]);

        builder.setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int item){
                if(item == mPairedDeviceCount) // 연결할 장치를 선택하지 않고 ‘취소’를 누른 경우
                    finish();
                else // 연결할 장치를 선택한 경우 선택한 장치와 연결을 시도함
                    connectToSelectedDevice(items[item].toString());
            }
        });
        builder.setCancelable(false);	// 뒤로 가기 버튼 사용 금지
        AlertDialog alert = builder.create();
        alert.show();
    }

    /**
     * 선택된 장치와 블루투스 연결을 하는 메소드
     * @param selectedDeviceName
     */
    private void connectToSelectedDevice(String selectedDeviceName){
        mRemoteDevice = getDeviceFromBondedList(selectedDeviceName);
        UUID uuid = UUID.fromString(HC06_UUID);

        try{
            // 소켓 생성
            mSocket = mRemoteDevice.createRfcommSocketToServiceRecord(uuid);
            // RFCOMM 채널을 통한 연결
            mSocket.connect();

            // 데이터 송신을 위한 스트림 얻기
            mOutputStream = mSocket.getOutputStream();
        }catch(Exception e) {   // 블루투스 연결 중 오류 발생
            finish();		    // 어플리케이션 종료
        }
    }

    /**
     * 장치이름을 받아서 블루투스장치 이름을 반환하는 메소드
     * @param name  장치 이름
     * @return 장치 이름에 해당하는 장치
     */
    private BluetoothDevice getDeviceFromBondedList(String name){
        BluetoothDevice selectedDevice = null;
        ((TextView)findViewById(R.id.connection_status_textview)).setText(name);
        for (BluetoothDevice device : mDevices) {
            if(name.equals(device.getName())){
                selectedDevice = device;
                break;
            }
        }
        return selectedDevice;
    }

    private void sendData(String message) {
        if(mOutputStream == null)
            finish();
        message += "\n";
        try{
            mOutputStream.write(message.getBytes());
        } catch (IOException e) {
            finish();
        }
    }
}
