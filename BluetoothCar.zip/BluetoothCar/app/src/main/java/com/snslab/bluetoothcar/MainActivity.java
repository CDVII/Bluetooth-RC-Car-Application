package com.snslab.bluetoothcar;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    TextView mTvBluetoothStatus;
    TextView mTvModeStatus;
    //TextView mTvReceiveData;      // 사용 계획 없음
    EditText mEtSendForwardValue;
    EditText mEtSendBackwardValue;
    EditText mEtSendLeftValue;
    EditText mEtSendRightValue;
    Button mBtnBluetoothConnect;
    Button mBtnBluetoothDisconnect;
    Button mBtnAppExit;
    Button mBtnModeChange;
    Button mBtnAutoMove;
    Button mBtnForward, mBtnBackward, mBtnLeft, mBtnRight, mBtnSpeedUp, mBtnSpeedDown;

    BluetoothAdapter mBluetoothAdapter;
    Set<BluetoothDevice> mPairedDevices;
    List<String> mListPairedDevices;
    Handler mBluetoothHandler;
    ConnectedBluetoothThread mThreadConnectedBluetooth;
    BluetoothDevice mBluetoothDevice;
    BluetoothSocket mBluetoothSocket;
    boolean autoModeState;

    final static int BT_REQUEST_ENABLE = 1;
    final static int BT_MESSAGE_READ = 2;
    final static int BT_CONNECTING_STATUS = 3;
    final static UUID BT_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        mTvBluetoothStatus = (TextView)findViewById(R.id.tvBluetoothStatus);
        mTvModeStatus = (TextView)findViewById(R.id.tvModeState);
        //mTvReceiveData = (TextView)findViewById(R.id.tvReceiveData);      // 사용 계획 없음
        mEtSendForwardValue =  (EditText) findViewById(R.id.forwardValue);
        mEtSendBackwardValue =  (EditText) findViewById(R.id.backwardValue);
        mEtSendLeftValue =  (EditText) findViewById(R.id.leftValue);
        mEtSendRightValue =  (EditText) findViewById(R.id.rightValue);
        mBtnBluetoothConnect = (Button)findViewById(R.id.btnBluetoothConnect);
        mBtnBluetoothDisconnect = (Button)findViewById(R.id.btnBluetoothDisconnect);
        mBtnAppExit = (Button)findViewById(R.id.btnAppExit);
        mBtnModeChange = (Button)findViewById(R.id.btnModeChange);
        mBtnAutoMove = (Button)findViewById(R.id.btnAutoMove);
        mBtnForward = (Button)findViewById(R.id.btnForward);
        mBtnBackward = (Button)findViewById(R.id.btnBackward);
        mBtnLeft = (Button)findViewById(R.id.btnLeft);
        mBtnRight = (Button)findViewById(R.id.btnRight);
        mBtnSpeedUp = (Button)findViewById(R.id.btnSpeedUp);
        mBtnSpeedDown = (Button)findViewById(R.id.btnSpeedDown);

        autoModeState = true;
        autoModuleEnable();
        controlModuleDisable();

        mBtnBluetoothConnect.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                bluetoothOn();
            }
        });
        mBtnBluetoothDisconnect.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                bluetoothOff();
            }
        });
        mBtnAppExit.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mThreadConnectedBluetooth != null)
                    mThreadConnectedBluetooth.write("q");
                bluetoothOff();
                finish();
            }
        });
        mBtnModeChange.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mThreadConnectedBluetooth != null) {
                    mThreadConnectedBluetooth.write("m");
                    if (autoModeState) {
                        autoModeState = false;
                        mBtnModeChange.setText("자동모드로 전환");
                        ((TextView) findViewById(R.id.tvModeState)).setText("현재 : 수동모드");
                        autoModuleDisable();
                        controlMouldeEnable();
                    } else {
                        autoModeState = true;
                        mBtnModeChange.setText("수동모드로 전환");
                        ((TextView) findViewById(R.id.tvModeState)).setText("현재 : 자동모드");
                        autoModuleEnable();
                        controlModuleDisable();
                    }
                }
                else
                    Toast.makeText(getApplicationContext(), "블루투스 장치와 연결이 되어 있지 않습니다.", Toast.LENGTH_LONG).show();
            }
        });
        mBtnAutoMove.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mThreadConnectedBluetooth != null) {
                    mThreadConnectedBluetooth.write(mEtSendForwardValue.getText().toString() + "," + mEtSendBackwardValue.getText().toString() + "," + mEtSendLeftValue.getText().toString() + "," + mEtSendRightValue.getText().toString());
                    mEtSendForwardValue.setText("");
                    mEtSendBackwardValue.setText("");
                    mEtSendLeftValue.setText("");
                    mEtSendRightValue.setText("");
                }
                else {
                    Toast.makeText(getApplicationContext(), "블루투스 장치와 연결이 되어 있지 않습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });
        mBtnForward.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mThreadConnectedBluetooth != null)
                    mThreadConnectedBluetooth.write("w");
                else
                    Toast.makeText(getApplicationContext(), "블루투스 장치와 연결이 되어 있지 않습니다.", Toast.LENGTH_LONG).show();
            }
        });
        mBtnBackward.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mThreadConnectedBluetooth != null)
                    mThreadConnectedBluetooth.write("s");
                else
                    Toast.makeText(getApplicationContext(), "블루투스 장치와 연결이 되어 있지 않습니다.", Toast.LENGTH_LONG).show();
            }
        });
        mBtnLeft.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mThreadConnectedBluetooth != null)
                    mThreadConnectedBluetooth.write("a");
                else
                    Toast.makeText(getApplicationContext(), "블루투스 장치와 연결이 되어 있지 않습니다.", Toast.LENGTH_LONG).show();
            }
        });
        mBtnRight.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mThreadConnectedBluetooth != null)
                    mThreadConnectedBluetooth.write("d");
                else
                    Toast.makeText(getApplicationContext(), "블루투스 장치와 연결이 되어 있지 않습니다.", Toast.LENGTH_LONG).show();
            }
        });
        mBtnSpeedUp.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mThreadConnectedBluetooth != null)
                    mThreadConnectedBluetooth.write("p");
                else
                    Toast.makeText(getApplicationContext(), "블루투스 장치와 연결이 되어 있지 않습니다.", Toast.LENGTH_LONG).show();
            }
        });
        mBtnSpeedDown.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mThreadConnectedBluetooth != null)
                    mThreadConnectedBluetooth.write("o");
                else
                    Toast.makeText(getApplicationContext(), "블루투스 장치와 연결이 되어 있지 않습니다.", Toast.LENGTH_LONG).show();
            }
        });
        mBluetoothHandler = new Handler(){
            public void handleMessage(Message msg){
                if(msg.what == BT_MESSAGE_READ){
                    String readMessage = null;
                    try {
                        readMessage = new String((byte[]) msg.obj, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    //mTvReceiveData.setText(readMessage);
                }
            }
        };
    }

    void bluetoothOn() {
        if(mBluetoothAdapter == null) {
            Toast.makeText(getApplicationContext(), "블루투스를 지원하지 않는 기기입니다.", Toast.LENGTH_LONG).show();
        }
        else {
            if(mBluetoothAdapter.isEnabled()) {
                // Toast.makeText(getApplicationContext(), "블루투스가 이미 활성화 되어 있습니다.", Toast.LENGTH_LONG).show();
                mTvBluetoothStatus.setText("활성화");
                listPairedDevices();
            }
            else {
                Toast.makeText(getApplicationContext(), "블루투스가 비활성화 되어 있습니다.", Toast.LENGTH_LONG).show();
                Intent intentBluetoothEnable = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(intentBluetoothEnable, BT_REQUEST_ENABLE);
            }
        }
    }

    void bluetoothOff() {
        if(mBluetoothAdapter.isEnabled()) {
            mBluetoothAdapter.disable();
            Toast.makeText(getApplicationContext(), "블루투스가 비활성화 되었습니다.", Toast.LENGTH_SHORT).show();
            mTvBluetoothStatus.setText("비활성화");
        }
        else {
            Toast.makeText(getApplicationContext(), "블루투스가 이미 비활성화 되어 있습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case BT_REQUEST_ENABLE:
                if (resultCode == RESULT_OK) { // 블루투스 활성화를 확인을 클릭하였다면
                    Toast.makeText(getApplicationContext(), "블루투스가 활성화 되었습니다.", Toast.LENGTH_LONG).show();
                    mTvBluetoothStatus.setText("활성화");
                    listPairedDevices();
                } else if (resultCode == RESULT_CANCELED) { // 블루투스 활성화를 취소를 클릭하였다면
                    Toast.makeText(getApplicationContext(), "취소되었습니다.", Toast.LENGTH_LONG).show();
                    mTvBluetoothStatus.setText("비활성화");
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    void listPairedDevices() {
        if (mBluetoothAdapter.isEnabled()) {
            mPairedDevices = mBluetoothAdapter.getBondedDevices();

            if (mPairedDevices.size() > 0) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("장치 선택");

                mListPairedDevices = new ArrayList<String>();
                for (BluetoothDevice device : mPairedDevices) {
                    mListPairedDevices.add(device.getName());
                    //mListPairedDevices.add(device.getName() + "\n" + device.getAddress());
                }
                final CharSequence[] items = mListPairedDevices.toArray(new CharSequence[mListPairedDevices.size()]);
                mListPairedDevices.toArray(new CharSequence[mListPairedDevices.size()]);

                builder.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {
                        connectSelectedDevice(items[item].toString());
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            } else {
                Toast.makeText(getApplicationContext(), "페어링된 장치가 없습니다.", Toast.LENGTH_LONG).show();
            }
        }
        else {
            Toast.makeText(getApplicationContext(), "블루투스가 비활성화 되어 있습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    void connectSelectedDevice(String selectedDeviceName) {
        for(BluetoothDevice tempDevice : mPairedDevices) {
            if (selectedDeviceName.equals(tempDevice.getName())) {
                mBluetoothDevice = tempDevice;
                break;
            }
        }
        try {
            mBluetoothSocket = mBluetoothDevice.createRfcommSocketToServiceRecord(BT_UUID);
            mBluetoothSocket.connect();
            mThreadConnectedBluetooth = new ConnectedBluetoothThread(mBluetoothSocket);
            mThreadConnectedBluetooth.start();
            mBluetoothHandler.obtainMessage(BT_CONNECTING_STATUS, 1, -1).sendToTarget();
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(), "블루투스 연결 중 오류가 발생했습니다.", Toast.LENGTH_LONG).show();
        }
    }

    void autoModuleEnable() {
        mEtSendForwardValue.setEnabled(true);
        mEtSendBackwardValue.setEnabled(true);
        mEtSendLeftValue.setEnabled(true);
        mEtSendRightValue.setEnabled(true);
        mBtnAutoMove.setEnabled(true);
    }

    void autoModuleDisable() {
        mEtSendForwardValue.setEnabled(false);
        mEtSendBackwardValue.setEnabled(false);
        mEtSendLeftValue.setEnabled(false);
        mEtSendRightValue.setEnabled(false);
        mBtnAutoMove.setEnabled(false);
    }

    void controlMouldeEnable() {
        mBtnForward.setEnabled(true);
        mBtnBackward.setEnabled(true);
        mBtnLeft.setEnabled(true);
        mBtnRight.setEnabled(true);
        mBtnSpeedUp.setEnabled(true);
        mBtnSpeedDown.setEnabled(true);
    }

    void controlModuleDisable() {
        mBtnForward.setEnabled(false);
        mBtnBackward.setEnabled(false);
        mBtnLeft.setEnabled(false);
        mBtnRight.setEnabled(false);
        mBtnSpeedUp.setEnabled(false);
        mBtnSpeedDown.setEnabled(false);
    }


    private class ConnectedBluetoothThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedBluetoothThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
                Toast.makeText(getApplicationContext(), "소켓 연결 중 오류가 발생했습니다.", Toast.LENGTH_LONG).show();
            }
            mTvBluetoothStatus.setText("장치 연결됨");

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }
        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;

            while (true) {
                try {
                    bytes = mmInStream.available();
                    if (bytes != 0) {
                        SystemClock.sleep(100);
                        bytes = mmInStream.available();
                        bytes = mmInStream.read(buffer, 0, bytes);
                        mBluetoothHandler.obtainMessage(BT_MESSAGE_READ, bytes, -1, buffer).sendToTarget();
                    }
                } catch (IOException e) {
                    break;
                }
            }
        }
        public void write(String str) {
            byte[] bytes = str.getBytes();
            try {
                mmOutStream.write(bytes);
            } catch (IOException e) {
                Toast.makeText(getApplicationContext(), "데이터 전송 중 오류가 발생했습니다.", Toast.LENGTH_LONG).show();
            }
        }
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Toast.makeText(getApplicationContext(), "소켓 해제 중 오류가 발생했습니다.", Toast.LENGTH_LONG).show();
            }
        }
    }
}